var weather = fetch(
  "http://api.openweathermap.org/data/2.5/weather?q=Bergen-Enkheim&appid=6aea1bd3a7e828969e6e4849335e1b66&units=metric"
);

let weatherTemperature = document.getElementById("temperature");
let weatherTemperatureFeels = document.getElementById("feels-like");
let weatherHumidity = document.getElementById("humidity");
let weatherIcon = document.getElementById("weather-icon");

//modeCounter will check for dark or light mode
//0 == light mode
//1 == dark mode

const body = document.getElementById("body");
let container = document.getElementById("holder");
let modeBtn = document.getElementById("modeBtn");
let modeCounter = 0;

modeBtn.addEventListener("click", () => {
  if (modeCounter === 0) {
    modeCounter++;
    modeChange();
    swapImage();
  } else if (modeCounter === 1) {
    modeCounter--;
    modeChange();
    swapImage();
  }
});
function modeChange() {
  if (modeCounter === 0) {
    body.style.background = "#f7f7f7";
    container.style.color = "black";
    modeBtn.style.color = "black";
    modeBtn.style.broder = "black";
  }
  if (modeCounter === 1) {
    body.style.background = "black";
    container.style.color = "#ebebeb";
    modeBtn.style.color = "white";
    modeBtn.style.broder = "white";
  }
}

weather
  //wenn daten zurückgegeben werden sollen dann nur die daten im json format zurückgegeben werden
  .then(data => data.json())
  //nachdem die daten im json format zurückgegeben wurden, werden alle variablen von Temperatur etc gesetzt.
  .then(function(data) {
    console.log(data);
    weatherTemperature.innerHTML = Math.round(data.main.temp) + "&#8451;";
    weatherTemperatureFeels.innerHTML =
      Math.round(data.main.feels_like) + "&#8451;";
    weatherHumidity.innerHTML = data.main.humidity + "%";
    weatherIcon = data.weather["0"].icon;
    document.getElementById("wind-speed").innerHTML = data.wind.speed + "m/s";
    swapImage();
  });
function swapImage() {
  if (modeCounter == 0) {
    //all dark images need to get displayed none before a new image can be shown

    document.getElementById("sunny-light").style.display = "none";
    document.getElementById("suncloud-light").style.display = "none";
    document.getElementById("clouds-light").style.display = "none";
    document.getElementById("heavyrain-light").style.display = "none";
    document.getElementById("rain-light").style.display = "none";
    document.getElementById("thunder-light").style.display = "none";
    document.getElementById("fog-light").style.display = "none";

    if (weatherIcon === "01d") {
      document.getElementById("sunny-dark").style.display = "block";
    } else if (weatherIcon === "02d") {
      document.getElementById("suncloud-dark").style.display = "block";
    } else if (weatherIcon === "03d") {
      document.getElementById("clouds-dark").style.display = "block";
    } else if (weatherIcon === "04d") {
      document.getElementById("clouds-dark").style.display = "block";
    } else if (weatherIcon === "09d") {
      document.getElementById("heavyrain-dark").style.display = "block";
    } else if (weatherIcon === "10d") {
      document.getElementById("rain-dark").style.display = "block";
    } else if (weatherIcon === "11d") {
      document.getElementById("thunder-dark").style.display = "block";
    } else if (weatherIcon === "13d") {
      document.getElementById("fog-dark").style.display = "block";
    }
  }

  if (modeCounter == 1) {
    //all dark images need to get displayed none before a new image can be shown

    document.getElementById("sunny-dark").style.display = "none";
    document.getElementById("suncloud-dark").style.display = "none";
    document.getElementById("clouds-dark").style.display = "none";
    document.getElementById("heavyrain-dark").style.display = "none";
    document.getElementById("rain-dark").style.display = "none";
    document.getElementById("thunder-dark").style.display = "none";
    document.getElementById("fog-dark").style.display = "none";

    if (weatherIcon === "01d") {
      document.getElementById("sunny-light").style.display = "block";
    } else if (weatherIcon === "02d") {
      document.getElementById("suncloud-light").style.display = "block";
    } else if (weatherIcon === "03d") {
      document.getElementById("clouds-light").style.display = "block";
    } else if (weatherIcon === "04d") {
      document.getElementById("clouds-light").style.display = "block";
    } else if (weatherIcon === "09d") {
      document.getElementById("heavyrain-light").style.display = "block";
    } else if (weatherIcon === "10d") {
      document.getElementById("rain-light").style.display = "block";
    } else if (weatherIcon === "11d") {
      document.getElementById("thunder-light").style.display = "block";
    } else if (weatherIcon === "13d") {
      document.getElementById("fog-light").style.display = "block";
    }
  }
}
